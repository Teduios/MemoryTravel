//
//  FaXianViewController.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FaXianViewController.h"
#import "FindViewCell.h"
#import "ImageViewController.h"
#import "PhotoViewController.h"

@interface FaXianViewController ()

@end

@implementation FaXianViewController
+ (UINavigationController *)standardTuWanNavi
{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        FaXianViewController *vc = [[FaXianViewController alloc]init];
        navi = [[UINavigationController alloc]initWithRootViewController:vc];
    });
    return navi;
}

#pragma mark - lazyLoad
- (FindViewmodel *)FindVM
{
    if (!_FindVM) {
        _FindVM = [[FindViewmodel alloc]init];
    }
    return _FindVM;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"专题";
    [self.tableView registerClass:[FindViewCell class] forCellReuseIdentifier:@"findCell"];
    
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.FindVM refreshDataCompletionHandle:^(NSError *error) {
            [self.tableView reloadData];
            [self.tableView.header endRefreshing];
            
            NSLog(@"................");
        }];
    }];
    self.tableView.footer = [MJRefreshAutoFooter footerWithRefreshingBlock:^{
       [self.FindVM getMoreDataCompletionHandle:^(NSError *error) {
           [self.tableView reloadData];
           [self.tableView.footer endRefreshing];
       }];
    }];
    
    [self.tableView.header beginRefreshing];

    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.FindVM.rowNumber;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FindViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"findCell"];
    cell.titleLb.text = [self.FindVM titleWithIndex:indexPath];
    cell.detailLb.text = [self.FindVM nameWithIndex:indexPath];
    [cell.imgView.imageView  setImageWithURL:[self.FindVM URLImageWithIndexPath:indexPath]];
    return cell;
}

#pragma mark - Table view delegate
//只要点击了该行的Cell就会触发该方法
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //松手后，去掉高亮状态
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    //ImageViewController*vc = [[ImageViewController alloc]init];
    //vc.imageURL = [self.FindVM URLImageWithIndexPath:indexPath];
    //[self.navigationController pushViewController:vc animated:YES];
    
    PhotoViewController  *vc = [PhotoViewController new];
    vc.firstURL = [self.FindVM URLImageWithIndexPath:indexPath];
    [self.navigationController pushViewController:vc animated:YES];
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 253;
}

-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewAutomaticDimension;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}




@end
