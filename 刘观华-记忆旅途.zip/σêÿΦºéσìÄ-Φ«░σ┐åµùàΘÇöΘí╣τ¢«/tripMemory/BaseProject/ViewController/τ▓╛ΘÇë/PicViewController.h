//
//  PicViewController.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PSCollectionView.h"
@interface PicViewController :UIViewController

@property (nonatomic , assign)NSInteger infoType;


@end
