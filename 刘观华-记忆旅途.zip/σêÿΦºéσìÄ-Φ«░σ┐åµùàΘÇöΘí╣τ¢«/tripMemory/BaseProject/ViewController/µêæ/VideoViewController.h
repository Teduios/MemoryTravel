//
//  MyselfViewController.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VideoViewModel.h"
@interface VideoViewController :UITableViewController
//+ (UINavigationController *)standardTuWanNavi;

@property (nonatomic , assign)NSInteger infoType;

@end
