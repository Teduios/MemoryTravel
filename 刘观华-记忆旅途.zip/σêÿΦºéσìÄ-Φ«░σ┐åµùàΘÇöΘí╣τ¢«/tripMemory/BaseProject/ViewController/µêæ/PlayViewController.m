//
//  PlayViewController.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PlayViewController.h"
#import "MediaPlayer/MediaPlayer.h"
@interface PlayViewController ()<UIWebViewDelegate>

@property (nonatomic,strong) UIWebView * webView;

@end

@implementation PlayViewController

-(UIWebView*)webView
{
    if (!_webView) {
        _webView = [[UIWebView alloc]init];
        _webView.delegate = self; //将自己设置为代理
    }
    return _webView;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    [Factory addBackItemToVC:self];
    [self.view addSubview:self.webView];
    [self.webView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    NSURLRequest * request  = [NSURLRequest requestWithURL:self.webUrl];
    [self.webView loadRequest:request];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
