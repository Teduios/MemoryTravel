//
//  MyselfViewController.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoViewController.h"
#import "VideoViewCell.h"
#import "MovieViewCell.h"
#import "PlayViewController.h"
#import <MediaPlayer/MediaPlayer.h>
#import <AVKit/AVKit.h>

@interface VideoViewController ()
@property (nonatomic,strong) VideoViewModel * videoVM;


@end

@implementation VideoViewController

+ (AVPlayerViewController *)sharedInstance{
    static AVPlayerViewController *vc = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        vc = [AVPlayerViewController new];
    });
    return vc;
}


#pragma mark - lazyLoad
- (VideoViewModel *)videoVM
{
    if (!_videoVM) {
        _videoVM = [[VideoViewModel alloc]initWithType:self.infoType];
    }
    return _videoVM;
}


/*
+ (UINavigationController *)standardTuWanNavi
{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        VideoViewController  *vc = [VideoViewController new];
        navi = [[UINavigationController alloc]initWithRootViewController:vc];
    });
    return navi;
}
 */


- (void)viewDidLoad {
    [super viewDidLoad];
    //self.title = @"微视";
    [self.tableView registerClass:[VideoViewCell class] forCellReuseIdentifier:@"videoCell"];
    
    
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.videoVM refreshDataCompletionHandle:^(NSError *error) {
            [self.tableView reloadData];
            [self.tableView.header endRefreshing];
            //NSLog(@"....................");
        }];
    }];
    
    self.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self.videoVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.tableView reloadData];
            [self.tableView.footer endRefreshing];
        }];
    }];
    
    [self.tableView.header beginRefreshing];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.videoVM.rowNumber;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    VideoViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"videoCell" forIndexPath:indexPath];
    [cell.imgView.imageView setImageWithURL:[self.videoVM coverImageURLWithIndexPath:indexPath]];
    cell.titleLb.text = [self.videoVM titleNameWithIndexPath:indexPath];
    cell.durationLb.text = [self.videoVM durationWithIndexPath:indexPath];
    
//    cell.titleLb.text = [self.videoVM titleNameWithIndexPath:indexPath];
//    cell.descLb.text = [self.videoVM durationWithIndexPath:indexPath];
//    
//    [cell.iconBtn setBackgroundImageForState:0 withURL:[self.videoVM coverImageURLWithIndexPath:indexPath]];
//    cell.videoURL= [self.videoVM playUrlWithIndexPath:indexPath];
    
    return cell;
}



#pragma mark - Table view delegate
//只要点击了该行的Cell就会触发该方法
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //松手后，去掉高亮状态
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    PlayViewController *playVC = [[PlayViewController alloc]init];
    playVC.webUrl = [self.videoVM webUrlWithIndexPath:indexPath];
    [self.navigationController pushViewController:playVC animated:YES];
    
    

}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return kWindowW * 210/300.0;
}


-(AVPlayerViewController*) sharedInstance
{
    static AVPlayerViewController *vc = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        vc = [AVPlayerViewController new];
    });
    return nil;
}

@end
