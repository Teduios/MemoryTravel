//
//  StrategyViewController.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StrategyViewController : UITableViewController
+ (UINavigationController *)standardTuWanNavi;
@end
