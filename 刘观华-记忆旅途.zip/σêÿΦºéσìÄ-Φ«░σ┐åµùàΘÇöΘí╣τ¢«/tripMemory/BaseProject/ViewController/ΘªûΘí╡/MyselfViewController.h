//
//  MyselfViewController.h
//  BaseProject
//
//  Created by ios-user23 on 15/12/1.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyselfViewController : UITableViewController
//+ (UINavigationController *)standardTuWanNavi;
@end
