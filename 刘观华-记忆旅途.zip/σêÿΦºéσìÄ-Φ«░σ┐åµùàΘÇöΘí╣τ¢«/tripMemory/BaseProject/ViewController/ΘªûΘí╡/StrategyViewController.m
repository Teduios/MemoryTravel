//
//  StrategyViewController.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "StrategyViewController.h"
#import "StrategyViewModel.h"
#import "StrategyViewCell.h"
#import "StrategyDetailController.h"

@interface StrategyViewController ()
@property (nonatomic,strong) StrategyViewModel * StrategyVM;
@end

@implementation StrategyViewController

+ (UINavigationController *)standardTuWanNavi
{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        StrategyViewController  *vc = [[StrategyViewController alloc]init];
        navi = [[UINavigationController alloc]initWithRootViewController:vc];
    });
    return navi;
}

#pragma mark - lazyLoad
- (StrategyViewModel *)StrategyVM
{
    if (!_StrategyVM) {
        _StrategyVM = [[StrategyViewModel alloc]init];
    }
    return _StrategyVM;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"攻略";
    [Factory addMenuItemToVC:self];
    self.tableView.backgroundColor = [UIColor lightGrayColor];
    [self.tableView registerClass:[StrategyViewCell class] forCellReuseIdentifier:@"StrategyCell"];
    /**头部刷新*/
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.StrategyVM refreshDataCompletionHandle:^(NSError *error) {
            [self.tableView reloadData];
            [self.tableView.header endRefreshing];
            NSLog(@"..............");
        }];
    }];
    /**尾部加载*/
    self.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self.StrategyVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.tableView reloadData];
            [self.tableView.footer endRefreshing];
        }];
    }];
    
    [self.tableView.header beginRefreshing];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.StrategyVM.rowNumber;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    StrategyViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"StrategyCell" forIndexPath:indexPath];
    cell.contentView.backgroundColor = [UIColor lightGrayColor];
    [cell.imgView.imageView setImageWithURL:[self.StrategyVM URLImageWithIndex:indexPath.row]];
    cell.titleLb.text = [self.StrategyVM titleWithIndex:indexPath.row];
    return cell;
}

#pragma mark - Table view delegate
//只要点击了该行的Cell就会触发该方法
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //松手后，去掉高亮状态
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    StrategyDetailController *vc  = [[StrategyDetailController alloc]init];
    vc.detailURL = [self.StrategyVM URLDetailWithIndex:indexPath.row];
    [self.navigationController pushViewController:vc animated:YES];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return kWindowW*0.9/1.6;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
