//
//  TripDetailController.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TripDetailController.h"

@interface TripDetailController ()<UIWebViewDelegate>
@property (nonatomic,strong) UIWebView * webView;

@property (nonatomic,strong) MBProgressHUD * loadHUD;

@property (nonatomic,strong) UIImageView * imgView;

@property (nonatomic,strong)NSArray * allImage;

@end

@implementation TripDetailController

#pragma mark - lazyLoad
- (NSArray *)allImage
{
    NSMutableArray *arr = [NSMutableArray new];
    if (!_allImage) {
        
        for (int i=0; i<29; i++) {
            // 生成图片路径
            NSString *imageName = [NSString stringWithFormat:@"refresh%d.png",i];
            NSString *path = [[NSBundle mainBundle] pathForResource:imageName ofType:nil];
            
            // 创建图片对象
            UIImage *image = [UIImage imageWithContentsOfFile:path];
            
            // 图片对象添加到数组中
            [arr addObject:image];
        }

    }
    return [arr copy];
}

#pragma mark - lazyLoad
- (UIImageView *)imgView
{
    if (!_imgView) {
        _imgView = [[UIImageView alloc]init];
        _imgView.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _imgView;
}

#pragma mark - lazyLoad
-(UIWebView*)webView
{
    if (!_webView) {
        _webView = [[UIWebView alloc]init];
        _webView.delegate = self;
    }
    return _webView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [Factory addBackItemToVC:self];
    [self.view addSubview:self.webView];
    [self.webView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    
    [self.view addSubview:self.imgView];
    [self.imgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.height.mas_equalTo(40);
        make.top.mas_equalTo((kWindowH-66-44-40)/2.0);
        make.left.mas_equalTo((kWindowW-40)/2.0);
    }];
    
    NSURL *Url = [NSURL URLWithString:self.detailUrl];
    NSURLRequest * request  = [NSURLRequest requestWithURL:Url];
    [self.webView loadRequest:request];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark-UIWebViewDelegate

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    //YES代表加载网页  NO 代表不加载
    return YES;
}

- (void)webViewDidStartLoad:(UIWebView *)webView{
    //开始加载网页
    
    // 设置动画的图片来源数组
    self.imgView.animationImages = self.allImage;
    // 设置动画的时长
    self.imgView.animationDuration = 29*0.04;
    
    // 重复次数
    self.imgView.animationRepeatCount = 8;
    
    // 开始动画
    [self.imgView startAnimating];
    
    
    NSLog(@"webViewDidStartLoad");
    
    
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    //加载网页成功
    
    // 动画结束时，释放掉图片
    [self.imgView setHidden:YES];
    [self.imgView performSelector:@selector(setAnimationImages:) withObject:nil afterDelay:self.imgView.animationDuration];
   
    
    NSLog(@"webViewDidFinishLoad");
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error{
    //加载网页失败
    
    // 动画结束时，释放掉图片
    [self.imgView performSelector:@selector(setAnimationImages:) withObject:nil afterDelay:self.imgView.animationDuration];
    [self.imgView setHidden:YES];
    
    NSLog(@"didFailLoadWithError:%@", error.userInfo);
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
