//
//  QuanjingViewController.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WMPageController.h"
@interface QuanjingViewController :WMPageController
//内容页的首页应该是单例的，每次进程都只初始化一次
+ (UINavigationController *)standardTuWanNavi;
@end
