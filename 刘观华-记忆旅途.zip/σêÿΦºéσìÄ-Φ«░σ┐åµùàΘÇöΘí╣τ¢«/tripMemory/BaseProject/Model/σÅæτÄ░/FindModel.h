//
//  FindModel.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@interface FindModel : BaseModel

@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, assign) NSInteger destination_id;

@property (nonatomic, copy) NSString *image_url;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, assign) NSInteger updated_at;
@end
