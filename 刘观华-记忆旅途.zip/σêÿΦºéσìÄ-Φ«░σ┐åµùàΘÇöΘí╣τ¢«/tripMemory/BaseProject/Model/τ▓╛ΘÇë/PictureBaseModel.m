//
//  PictureBaseModel.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PictureBaseModel.h"

@implementation PictureBaseModel


+ (NSDictionary *)objectClassInArray{
    return @{@"data" : [PicDataModel class]};
}
@end
@implementation PicDataModel

+(NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"ID":@"id"};
}

@end


