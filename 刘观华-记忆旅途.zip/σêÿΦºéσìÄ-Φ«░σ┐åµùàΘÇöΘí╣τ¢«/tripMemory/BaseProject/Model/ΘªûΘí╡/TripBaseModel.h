//
//  TripBaseModel.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class DataModel;
@interface TripBaseModel : BaseModel

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) NSArray<DataModel *> *data;

@property (nonatomic, copy) NSString *info;

@property (nonatomic, copy) NSString *ra_referer;

@property (nonatomic, assign) NSInteger times;

@end
@interface DataModel : NSObject

@property (nonatomic, assign) NSInteger id;

@property (nonatomic, copy) NSString *view_author_url;

@property (nonatomic, assign) NSInteger digest_level;

@property (nonatomic, copy) NSString *lastpost;

@property (nonatomic, copy) NSString *likes;

@property (nonatomic, copy) NSString *replys;

@property (nonatomic, copy) NSString *user_id;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *avatar;

@property (nonatomic, copy) NSString *view_url;

@property (nonatomic, copy) NSString *username;

@property (nonatomic, copy) NSString *photo;

@property (nonatomic, assign) NSInteger views;

@end

