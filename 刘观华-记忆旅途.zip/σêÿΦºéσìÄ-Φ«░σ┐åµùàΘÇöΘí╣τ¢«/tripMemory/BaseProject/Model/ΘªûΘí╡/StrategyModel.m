//
//  StrategyModel.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "StrategyModel.h"

@implementation StrategyModel

@end

@implementation StrateDataModel

+ (NSDictionary *)objectClassInArray{
    return @{@"items" : [ItemsModel class]};
}

@end


@implementation PagingModel

@end


@implementation ItemsModel
+(NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"ID":@"id"};
}

@end


