//
//  StrategyModel.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class StrateDataModel,PagingModel,ItemsModel;

@interface StrategyModel : BaseModel

@property (nonatomic, copy) NSString *message;

@property (nonatomic, strong) StrateDataModel *data;

@property (nonatomic, assign) NSInteger code;

@end
@interface StrateDataModel : NSObject

@property (nonatomic, strong) NSArray<ItemsModel *> *items;

@property (nonatomic, strong) PagingModel *paging;

@end

@interface PagingModel : NSObject

@property (nonatomic, copy) NSString *next_url;

@end

@interface ItemsModel : NSObject

@property (nonatomic, copy) NSString *cover_image_url;

@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, assign) NSInteger published_at;

@property (nonatomic, assign) NSInteger created_at;

@property (nonatomic, copy) NSString *content_url;

@property (nonatomic, strong) NSArray *labels;

@property (nonatomic, copy) NSString *url;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *share_msg;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, assign) NSInteger updated_at;

@property (nonatomic, copy) NSString *short_title;

@property (nonatomic, assign) BOOL liked;

@property (nonatomic, assign) NSInteger likes_count;

@property (nonatomic, assign) NSInteger status;

@end

