//
//  TripCell.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TripCell.h"

@implementation TripCell

- (TRImageView *)imgView
{
    if (!_imgView) {
        _imgView = [[TRImageView alloc]init];
        //_imgView.contentMode = UIViewContentModeScaleAspectFill;
    }
    return _imgView;
}

#pragma mark - lazyLoad
- (UILabel *)titleLb
{
    if (!_titleLb) {
        _titleLb = [[UILabel alloc]init];
        _titleLb.font = [UIFont flatFontOfSize:17];
        _titleLb.textColor  = [UIColor greenSeaColor];
        _titleLb.numberOfLines = 2;
    }
    return _titleLb;
}
#pragma mark - lazyLoad
- (UILabel *)usernameLb
{
    if (!_usernameLb) {
        _usernameLb = [[UILabel alloc]init];
        _usernameLb.font = [UIFont systemFontOfSize:13];
        _usernameLb.textColor  = kRGBColor(67, 63, 72);
    }
    return _usernameLb;
}

//readImage
//commentImage
//readLb
//commentLb

#pragma mark - lazyLoad
- (TRImageView *)readImage
{
    if (!_readImage) {
        _readImage = [[TRImageView alloc]init];
        UIImage *img = [UIImage imageNamed:@"read"];
        _readImage.imageView.image = img;
    }
    return _readImage;
}

#pragma mark - lazyLoad
- (UILabel *)commentLb
{
    if (!_commentLb) {
        _commentLb = [[UILabel alloc]init];
        _commentLb.font = [UIFont systemFontOfSize:12];
    }
    return _commentLb;
}

#pragma mark - lazyLoad
- (TRImageView *)commentImage
{
    if (!_commentImage) {
        _commentImage = [[TRImageView alloc]init];
        UIImage *img = [UIImage imageNamed:@"commend"];
        _commentImage.imageView.image = img;
    }
    return _commentImage;
}

#pragma mark - lazyLoad
- (UILabel *)readLb
{
    if (!_readLb) {
        _readLb = [[UILabel alloc]init];
        _readLb.font = [UIFont systemFontOfSize:12];
    }
    return _readLb;
}




-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.imgView];
        [self.contentView addSubview:self.titleLb];
        [self.contentView addSubview:self.usernameLb];
        [self.contentView addSubview:self.readImage];
        [self.contentView addSubview:self.commentImage];
        [self.contentView addSubview:self.readLb];
        [self.contentView addSubview:self.commentLb];
        [self.imgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(0);
            make.left.top.mas_equalTo(5);
            make.bottom.mas_equalTo(-5);
            make.width.mas_equalTo(kWindowW*3/8.0);
        }];
        [self.titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.imgView.mas_right).mas_equalTo(10);
            make.right.mas_equalTo(-15);
            make.top.mas_equalTo(8);
        }];
        
        [self.readImage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottomMargin.mas_equalTo(self.imgView.mas_bottomMargin).mas_equalTo(0);
            make.left.mas_equalTo(self.imgView.mas_right).mas_equalTo(10);
            make.width.mas_equalTo(20);
            make.height.mas_equalTo(13);
        }];
        
        [self.readLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottomMargin.mas_equalTo(self.imgView.mas_bottomMargin).mas_equalTo(0);
            make.left.mas_equalTo(self.readImage.mas_right).mas_equalTo(3);
            make.width.mas_equalTo(45);

        }];
        
        [self.commentImage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottomMargin.mas_equalTo(self.imgView.mas_bottomMargin).mas_equalTo(0);
            make.left.mas_equalTo(self.readImage.mas_right).mas_equalTo(50);
            make.width.mas_equalTo(20);
            make.height.mas_equalTo(13);
        }];
        
        [self.commentLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottomMargin.mas_equalTo(self.imgView.mas_bottomMargin).mas_equalTo(0);
            make.left.mas_equalTo(self.commentImage.mas_right).mas_equalTo(2);
            make.width.mas_equalTo(45);
        }];
        
        [self.usernameLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.mas_equalTo(self.readImage.mas_top).mas_equalTo(-1);
            make.left.mas_equalTo(self.imgView.mas_right).mas_equalTo(10);
            make.width.mas_equalTo(100);
        }];
        
        
    }
    return self;
}



- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
