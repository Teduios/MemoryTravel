//
//  TRImageAddBtnView.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TRImageAddBtnView.h"

@implementation TRImageAddBtnView

- (FUIButton *)btn
{
    if (!_btn) {
        _btn = [FUIButton buttonWithType:UIButtonTypeSystem];
        _btn.buttonColor = [UIColor turquoiseColor];
        _btn.shadowColor = [UIColor greenSeaColor];
        _btn.shadowHeight = 3.0f;
        _btn.cornerRadius = 6.0f;
        [_btn setTitle:@"播放" forState:UIControlStateNormal];
        _btn.titleLabel.font = [UIFont boldFlatFontOfSize:16];
        [_btn setTitleColor:[UIColor cloudsColor] forState:UIControlStateNormal];
        [_btn setTitleColor:[UIColor cloudsColor] forState:UIControlStateHighlighted];
        //_btn.layer.cornerRadius = 2;
    }
    return _btn;
}

-(instancetype)init
{
    
    if (self = [super init]) {
        _imageView = [UIImageView new];
        [self addSubview:_imageView];
        //
        _imageView.contentMode = 2;
        [_imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        
        [_imageView addSubview:self.btn];
        
        [self.btn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.mas_equalTo(-10);
            make.right.mas_equalTo(-10);
            make.width.mas_equalTo(80);
            make.height.mas_equalTo(30);
        }];
        
        _imageView.userInteractionEnabled = YES;
        
        
        /**当前视图容器减掉超出自身区域的视图*/
        self.clipsToBounds = YES;
    }
    return self;
    
}
@end
