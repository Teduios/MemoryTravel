//
//  TRImageView.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TRImageView.h"

@implementation TRImageView

-(instancetype)init
{
    
    if (self = [super init]) {
        _imageView = [UIImageView new];
        [self addSubview:_imageView];
        //
        _imageView.contentMode = 2;
        _imageView.layer.cornerRadius = 3;
        [_imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        /**当前视图容器减掉超出自身区域的视图*/
        self.clipsToBounds = YES;
    }
    return self;

}

@end
