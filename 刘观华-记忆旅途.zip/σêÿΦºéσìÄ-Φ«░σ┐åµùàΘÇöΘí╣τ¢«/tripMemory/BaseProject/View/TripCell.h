//
//  TripCell.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRImageView.h"
@interface TripCell : UITableViewCell

@property (nonatomic,strong) TRImageView * imgView;

@property (nonatomic,strong) UILabel * titleLb;

@property (nonatomic,strong) UILabel * usernameLb;

@property (nonatomic,strong) TRImageView * readImage;

@property (nonatomic,strong) TRImageView * commentImage;

@property (nonatomic,strong) UILabel * readLb;

@property (nonatomic,strong) UILabel * commentLb;



@end
