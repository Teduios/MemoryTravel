//
//  StrategyViewCell.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "StrategyViewCell.h"

@implementation StrategyViewCell
#pragma mark - lazyLoad
- (TRImageView *)imgView
{
    if (!_imgView) {
        _imgView = [[TRImageView alloc]init];
    }
    return _imgView;
}
#pragma mark - lazyLoad
- (UILabel *)titleLb
{
    if (!_titleLb) {
        _titleLb = [[UILabel alloc]init];
        _titleLb.font = [UIFont fontWithName:@"TrebuchetMS-Bold" size:17];
        _titleLb.textColor = [UIColor colorWithWhite:1 alpha:1];
        _titleLb.numberOfLines = 0;
    }
    return _titleLb;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        [self.contentView addSubview:self.imgView];
        [self.contentView addSubview:self.titleLb];
        [self.imgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(0);
            make.top.mas_equalTo(0);
            make.right.mas_equalTo(0);
            make.bottom.mas_equalTo(0);
        }];
        [self.titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(2);
            make.bottom.mas_equalTo(-2);
            make.width.mas_equalTo(kWindowW);
        }];
    }
    return self;
}


- (void)awakeFromNib {
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    
}

@end
