//
//  MovieViewCell.m
//  BaseProject
//
//  Created by ios-user23 on 15/12/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MovieViewCell.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
#import "BlocksKit+UIKit.h"
@implementation MovieViewCell

//为了保证同一时间只有一个播放器，使用单例模式
+ (AVPlayerViewController *)sharedInstance{
    static AVPlayerViewController *vc = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        vc = [AVPlayerViewController new];
    });
    return vc;
}

#pragma mark - lazyLoad
- (UILabel *)titleLb
{
    if (!_titleLb) {
        _titleLb = [[UILabel alloc]init];
        _titleLb.font = [UIFont fontWithName:@"TrebuchetMS-Bold" size:16];
        //_titleLb.font = [UIFont flatFontOfSize:16];
        _titleLb.numberOfLines = 0;
        //设置字体居中
        //_titleLb.textAlignment = UITextAlignmentCenter;
    }
    return _titleLb;
}

#pragma mark - lazyLoad
- (UIButton *)iconBtn
{
    if (!_iconBtn) {
        _iconBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_iconBtn bk_addEventHandler:^(id sender) {
            AVPlayer *player=[AVPlayer playerWithURL:self.videoURL];
            [player play];
            [MovieViewCell sharedInstance].player = player;
            [sender addSubview:[MovieViewCell sharedInstance].view];
            [[MovieViewCell sharedInstance].view mas_makeConstraints:^(MASConstraintMaker *make) {
                make.edges.mas_equalTo(0);
            }];
        } forControlEvents:UIControlEventTouchUpInside];
    }
    return _iconBtn;
}

- (UILabel *)durationLb
{
    if (!_descLb) {
        _descLb = [[UILabel alloc]init];
        _descLb.font = [UIFont fontWithName:@"TrebuchetMS-Bold" size:13];
        _descLb.textColor = [UIColor lightGrayColor];
        //_descLb.font = [UIFont flatFontOfSize:13];
        //设置字体居中
        //_descLb.textAlignment = UITextAlignmentCenter;
    }
    return _descLb;
}



//如果cell被复用了，需要把cell上的播放器删掉
- (void)prepareForReuse{
    [super prepareForReuse];
    //判断当前cell是否有播放，如果有则删除-->自己想办法
    if ([MovieViewCell sharedInstance].view.superview == self.iconBtn) {
        [[MovieViewCell sharedInstance].view removeFromSuperview];
        [MovieViewCell sharedInstance].player = nil;
    }
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        [self.contentView addSubview:self.titleLb];
        [self.contentView addSubview:self.descLb];
        [self.contentView addSubview:self.iconBtn];
        
        [self.titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(0);
            make.left.mas_equalTo(0);
            make.width.mas_equalTo(kWindowW);
        }];
        [self.descLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.topMargin.mas_equalTo(self.titleLb.mas_bottomMargin).mas_equalTo(0);
            make.left.mas_equalTo(0);
            make.width.mas_equalTo(kWindowW);
        }];
        [self.iconBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.topMargin.mas_equalTo(self.descLb.mas_bottomMargin).mas_equalTo(2);
            make.left.mas_equalTo(2);
            make.right.mas_equalTo(-2);
            make.bottom.mas_equalTo(-2);
        }];
        
    }
    return self;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
