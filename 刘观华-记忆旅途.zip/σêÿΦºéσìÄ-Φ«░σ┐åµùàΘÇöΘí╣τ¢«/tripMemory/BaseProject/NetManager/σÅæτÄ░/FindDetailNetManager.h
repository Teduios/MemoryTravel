//
//  FindDetailNetManager.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"

@interface FindDetailNetManager : BaseNetManager
+(id)GetDataFromNetWithID :(NSInteger)ID CompletionHandle:(void(^)(id  responseObj,NSError *error))completionHandle;
@end
