//
//  StrategyNetManager.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "StrategyNetManager.h"
#import "StrategyModel.h"
@implementation StrategyNetManager

+(id)getStrategyModelDataWithPage:(NSInteger)page CompletionHandle:(void (^)(id responseObj,NSError *error))completionHandle
{
      NSString *path =[NSString stringWithFormat:@"http://api.guozhoumoapp.com/v1/channels/6/items?gender=1&generation=2&limit=20&offset=%ld",page];
      return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
          completionHandle([StrategyModel objectWithKeyValues:responseObj],error);
      }];
}

@end
