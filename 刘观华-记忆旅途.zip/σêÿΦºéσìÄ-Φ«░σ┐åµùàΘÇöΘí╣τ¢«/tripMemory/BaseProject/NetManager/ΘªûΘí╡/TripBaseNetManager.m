//
//  TripBaseNetManager.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TripBaseNetManager.h"

@implementation TripBaseNetManager
+(id)GetTripDataRromNetWithPage:(NSInteger)page CompletionHandle:(void(^)(id  responseObj,NSError *error))completionHandle
{
    NSString *path = [NSString stringWithFormat:@"http://open.qyer.com/qyer/recommands/trip?client_id=qyer_ios&client_secret=cd254439208ab658ddf9&count=10&page=%ld&track_app_channel=App%%2520Store&track_app_version=6.8&track_device_info=iPhone%%25204S&track_deviceid=B50C4A28-1844-4CE3-A58D-EA2A64A9CEDC&track_os=ios%%25207.1.2&type=index&v=1", page];
    
   
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([TripBaseModel objectWithKeyValues:responseObj],error);
    }];
    
}
@end
