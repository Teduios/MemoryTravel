//
//  VideoViewModel.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "VideoNetManager.h"
@interface VideoViewModel : BaseViewModel

@property (nonatomic,assign) VideoInfoType infoType;

@property (nonatomic , assign) NSInteger page;

@property (nonatomic , assign) NSInteger rowNumber;

-(instancetype)initWithType:(VideoInfoType)type;


-(NSURL *)coverImageURLWithIndexPath:(NSIndexPath *)indexPath;

-(NSString *)titleNameWithIndexPath:(NSIndexPath *)indexPath;

-(NSString *)durationWithIndexPath:(NSIndexPath *)indexPath;

-(NSURL*)webUrlWithIndexPath:(NSIndexPath*)indexPath;

-(NSURL*)playUrlWithIndexPath:(NSIndexPath*)indexPath;

@end
