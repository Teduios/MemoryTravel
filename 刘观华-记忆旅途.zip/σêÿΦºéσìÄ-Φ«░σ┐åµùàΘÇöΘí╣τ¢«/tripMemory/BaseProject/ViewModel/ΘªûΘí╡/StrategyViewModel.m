//
//  StrategyViewModel.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "StrategyViewModel.h"
#import "StrategyNetManager.h"
#import "StrategyModel.h"
@implementation StrategyViewModel

-(NSInteger)rowNumber
{
    return self.dataArr.count;
}
//获取更多
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle
{
    self.page += 10;
    [self getDataFromNetCompleteHandle:completionHandle];
}
//刷新
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    self.page = 10;
    [self getDataFromNetCompleteHandle:completionHandle];
}
//获取数据
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [StrategyNetManager getStrategyModelDataWithPage:_page CompletionHandle:^(StrategyModel *responseObj, NSError *error) {
        if (_page == 10) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:responseObj.data.items];
        completionHandle(error);
    }];
}

-(ItemsModel*)itemsModelWithIndex:(NSInteger)index
{
    return self.dataArr[index];
}

-(NSURL*)URLImageWithIndex:(NSInteger)index
{
    NSString *path = [self itemsModelWithIndex:index].cover_image_url;
    return [NSURL URLWithString:path];
}

-(NSString*)titleWithIndex:(NSInteger)index
{
    return [self itemsModelWithIndex:index].title;
}

-(NSURL*)URLDetailWithIndex:(NSInteger)index
{
    NSString *path = [self itemsModelWithIndex:index].url;
    return [NSURL URLWithString:path];
}

@end
