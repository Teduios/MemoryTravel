//
//  StrategyViewModel.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"

@interface StrategyViewModel : BaseViewModel

@property (nonatomic,assign) NSInteger  page;

@property (nonatomic , assign) NSInteger rowNumber;


-(NSString*)titleWithIndex:(NSInteger)index;

-(NSURL*)URLImageWithIndex:(NSInteger)index;

-(NSURL*)URLDetailWithIndex:(NSInteger)index;

@end
