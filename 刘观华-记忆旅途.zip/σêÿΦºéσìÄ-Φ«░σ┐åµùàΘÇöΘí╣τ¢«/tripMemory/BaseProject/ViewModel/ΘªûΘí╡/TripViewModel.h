//
//  TripViewModel.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"

@interface TripViewModel : BaseViewModel

@property (nonatomic , assign) NSInteger page;

@property (nonatomic , assign) NSInteger rowNumber;

-(NSURL *)imageURLWithIndexPath:(NSIndexPath *)indexPath;

-(NSString *)titleWithIndexPath:(NSIndexPath *)indexPath;

-(NSString *)userNameWithIndexPath:(NSIndexPath *)indexPath;

-(NSInteger)replysWithIndexPath:(NSIndexPath *)indexPath;

-(NSInteger)viewsWithIndexPath:(NSIndexPath *)indexPath;

-(NSString *)detailStrWithIndexPath:(NSIndexPath*)indexPath;

@end
