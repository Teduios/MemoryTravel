//
//  Factory.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "Factory.h"
#import <Foundation/Foundation.h>
@implementation Factory
/** 向某个控制器上，添加菜单按钮 */
+ (void)addMenuItemToVC:(RESideMenu *)vc
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, 0, 30, 30);
    [btn setBackgroundImage:[UIImage imageNamed:@"zone_post_red.png"] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:@"zone_post_red.png"] forState:UIControlStateHighlighted];
    [btn bk_addEventHandler:^(id sender) {
        
        /**这里写一些btn响应的代码*/
        [vc.sideMenuViewController presentLeftMenuViewController];
        
    } forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *menuItem = [[UIBarButtonItem alloc]initWithCustomView:btn];
    //使用弹簧控件缩小菜单按钮和边缘距离
    UIBarButtonItem *spaceItem = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    spaceItem.width = -10;
    vc.navigationItem.leftBarButtonItems = @[spaceItem,menuItem];
    
}

/** 向某个控制器上，添加返回按钮 "< 返回" */
+(void)addBackItemToVC:(UIViewController*)vc
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, 0,45,44);
    [btn setBackgroundImage:[UIImage imageNamed:@"btn_back_n.png"] forState:UIControlStateNormal];
    
    [btn setBackgroundImage:[UIImage imageNamed:@"btn_back_h.png"] forState:UIControlStateHighlighted];
    [btn bk_addEventHandler:^(id sender) {
        [vc.navigationController popViewControllerAnimated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *btnItem = [[UIBarButtonItem alloc]initWithCustomView:btn];
    
    UIBarButtonItem *spaceItem = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    
    spaceItem.width = -15;
    vc.navigationItem.leftBarButtonItems = @[spaceItem,btnItem];
}
@end
