//
//  AppDelegate.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+Category.h"

#import "FaXianViewController.h"
#import "TripViewController.h"
#import "VideoViewController.h"
#import "PicViewController.h"




#import "BaseNetManager.h"
#import "FindNetManager.h"
#import "FindDetailNetManager.h"
#import "TripBaseNetManager.h"
#import "StrategyNetManager.h"
#import "VideoNetManager.h"
#import "PictureNetManager.h"
#import "DCButtonViewController.h"
#import "QuanjingViewController.h"
#import "VideoPageViewController.h"
#import "LeftViewController.h"


@interface AppDelegate ()
@property (nonatomic,strong) UILabel * naviTitle;
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [self initializeWithApplication:application];
    
    
    
//    [TripNetManager getTripDataWithPage:1 completionHandle:^(id responseObj, NSError *error) {
//        
//        NSLog(@"............");
//    }];
    
//    [TripDetailNetManager getDetailDataWithGenId:300099 CompletionHandle:^(id responseObj, NSError *error) {
//        
//        NSLog(@"................");
//    }];
    
//    NSMutableArray  *arr = [NSMutableArray new];
//    [FindNetManager GetFindDataRromNetWithPage:1 CompletionHandle:^(NSArray* responseObj, NSError *error) {
//        [arr addObjectsFromArray:responseObj];
//        NSLog(@"...............");
//    }];
    
//    [FindDetailNetManager GetDataFromNetWithID:588 CompletionHandle:^(id responseObj, NSError *error) {
//        NSLog(@"..............");
//    }];
    
//    [TripBaseNetManager GetTripDataRromNetWithPage:2 CompletionHandle:^(id responseObj, NSError *error) {
//       
//        NSLog(@"................");
//    }];
    
    [StrategyNetManager getStrategyModelDataWithPage:10 CompletionHandle:^(id responseObj, NSError *error) {
        
        NSLog(@"................");
    }];
    
    
    [VideoNetManager GetVideoDataFromNetWithPage:20 type:VideoInfoTypeJilu CompletionHandle:^(id responseObj, NSError *error) {
        NSLog(@".................");
    }];
    //对self.window进行设置
    self.window  = [[UIWindow alloc]initWithFrame:[[UIScreen mainScreen]bounds]];
    self.window.backgroundColor = [UIColor whiteColor];
    
    UITabBarController *tabBarControl = [[UITabBarController alloc]init];
    
    //UINavigationController *vc1 = [TripViewController standardTuWanNavi];
    RESideMenu *vc1 = [[RESideMenu alloc]initWithContentViewController:[TripViewController standardTuWanNavi] leftMenuViewController:[LeftViewController new] rightMenuViewController:nil];
    vc1.backgroundImage = [UIImage imageNamed:@"Leftimage.png"];
    
    vc1.tabBarItem.title  = @"首页";
    vc1.tabBarItem.image = [UIImage imageNamed:@"TabBarIconFeaturedNormal"];
    vc1.tabBarItem.selectedImage = [[UIImage imageNamed:@"TabBarIconFeatured"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    vc1.view.backgroundColor = kRGBColor(70, 110, 166);
    [vc1.navigationItem.titleView addSubview:self.naviTitle];
    
    
    UINavigationController *vc2 = [QuanjingViewController standardTuWanNavi];
    [vc2.tabBarItem setTitle:@"全景"];
    vc2.tabBarItem.image = [UIImage imageNamed:@"TabBarIconDestinationNormal"];
    vc2.tabBarItem.selectedImage = [[UIImage imageNamed:@"TabBarIconDestination"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    vc2.view.backgroundColor = kRGBColor(164,164,164 );
    
    UINavigationController *vc3 = [FaXianViewController standardTuWanNavi];
    
    vc3.tabBarItem.title  = @"专题";
    vc3.tabBarItem.image = [UIImage imageNamed:@"TabBarIconToolbox"];
    vc3.tabBarItem.selectedImage = [[UIImage imageNamed:@"TabBarIconToolbox"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    vc3.view.backgroundColor = kRGBColor(arc4random_uniform(0), arc4random_uniform(255), arc4random_uniform(255));
    
    UINavigationController  *vc4 = [VideoPageViewController standardTuWanNavi];
    vc4.tabBarItem.title  = @"微视";
    vc4.tabBarItem.image = [UIImage imageNamed:@"TabBarIconMyNormal"];
    vc4.tabBarItem.selectedImage = [[UIImage imageNamed:@"TabBarIconMy"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];;
    vc4.view.backgroundColor = kRGBColor(arc4random_uniform(255), arc4random_uniform(0), arc4random_uniform(255));
    /**tabBarController里面包含4个控制器*/
    tabBarControl.viewControllers = @[vc1,vc2,vc3,vc4];
    
    self.window.rootViewController  = tabBarControl;
    [self.window makeKeyAndVisible];
    [self configGlobalUIStyle];
    return YES;
}

- (PictureViewModel *)picVM
{
    if (!_picVM) {
        _picVM = [[PictureViewModel alloc]init];
    }
    return _picVM;
}

/**配置全局导航栏的标题*/
#pragma mark - lazyLoad
- (UILabel *)naviTitle
{
    if (!_naviTitle) {
        _naviTitle = [[UILabel alloc]init];
        _naviTitle.text = @"记忆旅途";
    }
    return _naviTitle;
}

/**  配置全局UI样式 */
-(void)configGlobalUIStyle
{
    /** 导航栏不透明*/
    [[UINavigationBar appearance]setTranslucent:NO];
    //
    [[UINavigationBar appearance]setBackgroundImage:[UIImage imageNamed:@""]forBarMetrics:UIBarMetricsDefault];
    //
    [[UINavigationBar appearance]setTitleTextAttributes:@{NSFontAttributeName:[UIFont flatFontOfSize:kNaviTitleFontSize],NSForegroundColorAttributeName:kNaviTitleColor}];
}




@end
